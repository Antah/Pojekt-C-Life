#ifndef _RULES
        #define _RULES
        #include <stdio.h>

int rules(int neighboursAlive, int cellState);

#endif

