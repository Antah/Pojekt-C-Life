#ifndef _NEIGHBOURS
        #define _NEIGHBOURS
        #include <stdio.h>

int neighbours(int *neighboursTab);

#endif

